/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author louis
 */
public class MultiTableQueries {
    private static Connection connection;
    private static ArrayList<String> faculty = new ArrayList<String>();
    private static PreparedStatement getAllClassDescriptions;
    private static PreparedStatement getScheduledStudentsByClass;
    private static PreparedStatement getStudentName;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static ResultSet resultSet;

    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester) {
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> classDescriptions = new ArrayList<>();

        try {
            PreparedStatement getClassData = connection.prepareStatement(
                "select coursecode, seats from app.class where semester = ?");
            getClassData.setString(1, semester);
            ResultSet classDataResult = getClassData.executeQuery();

            while (classDataResult.next()) {
                String courseCode = classDataResult.getString("coursecode");
                int seats = classDataResult.getInt("seats");

                PreparedStatement getDescription = connection.prepareStatement(
                    "select description from app.course where coursecode = ?");
                getDescription.setString(1, courseCode);
                ResultSet descriptionResult = getDescription.executeQuery();

                if (descriptionResult.next()) {
                    String description = descriptionResult.getString("description");
                    ClassDescription descriptionObj = new ClassDescription(courseCode, description, seats);
                    classDescriptions.add(descriptionObj);
                }
            }
        }
        catch (SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return classDescriptions;
    }
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String courseCode)
    {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> ScheduledStudentList = new ArrayList<>();
        ArrayList<String> ScheduledStudentID = new ArrayList<>();
        try
        {
            getScheduledStudentsByClass = connection.prepareStatement("select studentid, status from app.schedule where semester = ? and coursecode = ?");
            getScheduledStudentsByClass.setString(1, semester);
            getScheduledStudentsByClass.setString(2, courseCode);
            resultSet = getScheduledStudentsByClass.executeQuery();
            while(resultSet.next())
            {
                String studentid = resultSet.getString("studentid");
                String status = resultSet.getString("status");
                if ("scheduled".equals(status)){
                    ScheduledStudentID.add(studentid);
                }
            }
            getStudentName = connection.prepareStatement("select firstname, lastname from app.student where studentid = ?");
            for (String studentID : ScheduledStudentID) {
                getStudentName.setString(1, studentID);
                ResultSet studentResult = getStudentName.executeQuery();
                if (studentResult.next()) {
                    String firstName = studentResult.getString("firstname");
                    String lastName = studentResult.getString("lastname");
                    StudentEntry studentEntry = new StudentEntry(studentID, firstName, lastName);
                    ScheduledStudentList.add(studentEntry);
                }
            }
        }
            catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return ScheduledStudentList;
    }
    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String courseCode)
    {
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> WaitlistStudentList = new ArrayList<>();
        ArrayList<String> WaitlistStudentID = new ArrayList<>();
        try
        {
            getWaitlistedStudentsByClass = connection.prepareStatement("select studentid, status from app.schedule where semester = ? and coursecode = ?");
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, courseCode);
            resultSet = getWaitlistedStudentsByClass.executeQuery();
            while(resultSet.next())
            {
                String studentid = resultSet.getString("studentid");
                String status = resultSet.getString("status");
                if ("waitlist".equals(status)){
                    WaitlistStudentID.add(studentid);
                }
            }
            getStudentName = connection.prepareStatement("select studentid, firstname, lastname from app.student where studentid = ?");
            for (String studentID : WaitlistStudentID) {
                getStudentName.setString(1, studentID);
                ResultSet studentResult = getStudentName.executeQuery();
                if (studentResult.next()) {
                    String firstName = studentResult.getString("firstname");
                    String lastName = studentResult.getString("lastname");
                    StudentEntry studentEntry = new StudentEntry(studentID, firstName, lastName);
                    WaitlistStudentList.add(studentEntry);
                }
            }
        }
            catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return WaitlistStudentList;
    }
}